from django.http import HttpResponse

def index(request):
    return HttpResponse('''<h1><a href="https://www.facebook.com/">Facebook</h1></a> <h1><a href="https://www.youtube.com/">Youtube</h1></a> <h1><a href="https://www.google.com/">Google</h1></a> ''')